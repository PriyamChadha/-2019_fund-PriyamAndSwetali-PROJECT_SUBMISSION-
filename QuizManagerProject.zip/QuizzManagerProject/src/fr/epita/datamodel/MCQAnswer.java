package fr.epita.datamodel;

public class MCQAnswer {
	
	private MCQChoice choice;
	
	private Student student;

	/**
	 * @return the choice
	 */
	public MCQChoice getChoice() {
		return choice;
	}

	/**
	 * @param choice the choice to set
	 */
	public void setChoice(MCQChoice choice) {
		this.choice = choice;
	}

	/**
	 * @return the student
	 */
	public Student getStudent() {
		return student;
	}

	/**
	 * @param student the student to set
	 */
	public void setStudent(Student student) {
		this.student = student;
	}


	
}
