package fr.epita.datamodel;

public class MCQQuestion extends Question {

	public MCQQuestion() {
		super();
		
	}

	/**
	 * @param question
	 */
	public MCQQuestion(String question) {
		super(question);
		
	}

	
}
