package fr.epita.datamodel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fr.epita.logger.Logger;
import fr.epita.services.dao.AnswerJDBCDAO;
import fr.epita.services.dao.MCQChoiceJDBCDAO;
import fr.epita.services.dao.MCQQuestionJDBCDAO;
import fr.epita.services.dao.QuestionJDBCDAO;
import fr.epita.services.dao.QuizDAO;

/**
 * @author priyamchadha
 *The class with main function,
 *handling all the control flow of the system.
 */
public class QuizManager {
	
	public static void main(String[] args) {
		
		System.out.println("Login as:");
		System.out.println("1. Student");
		System.out.println("2. Teacher");
		Scanner scann = new Scanner(System.in);
		String Choice = scann.nextLine();
		switch(Choice) {
			case "1":
				StudentManager SM = new StudentManager();
				SM.StudentMenu();
					break;
			
			case "2": 
				login();
					break;
		
	}
	}
	
	/**
	 * ensures the user who is login in the system is authentic.
	 */
	private static void login() {
		Scanner scanner = new Scanner(System.in);
		if (authenticate(scanner)) {

			System.out.println("You are authenticated !");

			menu(scanner);

		} else {
			System.out.println("Authentication failed.");
		}
	}

	/**
	 * @param scanner
	 * gets the username and password from the user and verifies it again the details stored in the system,
	 * in the file.
	 * @return
	 */
	private static boolean authenticate(Scanner scanner) {
		System.out.println("Please enter your login : ");
		String userLoginInput = scanner.nextLine();
		System.out.println("Please enter your password : ");
		String userPasswordInput = scanner.nextLine();
		
		File file = new File("password.txt");
		Scanner credentialsScanner = null;
		try {
			credentialsScanner = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		if (credentialsScanner == null) {
			scanner.close();
			return false;
		}
		String line = credentialsScanner.nextLine();
		String[] parts = line.split(":");
		
	
		return parts[0].equals(userLoginInput) && parts[1].equals(userPasswordInput);
		
	}
	
	/**
	 * @param scanner
	 * Displays the main menu to the teacher, giving options of the actions that can be done.
	 * get the choice from the user and directs control accordingly.
	 */
	private static void menu(Scanner scanner) {
		boolean exit = false;
		do {
			System.out.println("\n Please choose one of the following options : \n 1.Create a Question, \n 2.Modify a Question, \n 3.Delete a Question, \n 4.Search a question/List of Question, \n 5.Create and export a Quiz, \n 6.Exit");
			String userMenuInput = scanner.nextLine();
			switch (userMenuInput) {
			case "1":
				System.out.println("Create :\n a) Open Question \n b) MCQ Question");
				String ch = scanner.nextLine();
				if(ch.equalsIgnoreCase("a")){
					createOpenQuestion(scanner);
				}
				else if(ch.equalsIgnoreCase("b")){
					createMCQQuestion(scanner);
				}
				else {
					System.out.println("Invalid choice");
					menu(scanner);
				}
				System.out.println("Question Created ! ");
				break;
			case "2":
				System.out.println("Update :\n a) Open Question \n b) MCQ Question");
				String ch1 = scanner.nextLine();
				if(ch1.equalsIgnoreCase("a")){
					updateOpenQuestion(scanner);
				}
				else if(ch1.equalsIgnoreCase("b")){
					updateMCQQuestion(scanner);
				}
				else {
					System.out.println("Invalid choice");
					menu(scanner);
				}
				System.out.println("Question Updated ! ");
				break;
			case "3":
				System.out.println("Delete :\n a) Open Question \n b) MCQ Question");
				String ch2 = scanner.nextLine();
				if(ch2.equalsIgnoreCase("a")){
					deleteOpenQuestion(scanner);
				}
				else if(ch2.equalsIgnoreCase("b")){
					deleteMCQQuestion(scanner);
				}
				else {
					System.out.println("Invalid choice");
					menu(scanner);
				}
				System.out.println("Question Deleted ! ");
				break;
				
			case "4":
				System.out.println("Get :\n a) List of all Open Questions \n b) List of all MCQ Questions \n c) Topic wise Open questions \n d)Toipc wise MCQ Qusetions");
				String ch3 = scanner.nextLine();
				if(ch3.equalsIgnoreCase("a")) {
					allOpenQuestions();
				}
				else if(ch3.equalsIgnoreCase("b")) {
					allMCQQuestions();
				}
				else if(ch3.equalsIgnoreCase("c")) {
					topicSearchOpenQuestion(scanner);
				}
				else if(ch3.equalsIgnoreCase("d")) {
					topicSearchMCQQuestion(scanner);
				}
				else {
					System.out.println("Invalid choice");
					menu(scanner);
				}
				break;
			case "5":
				createQuiz(scanner);
				break;
			case "6":
				System.out.println("You've selected to exit the application");
				exit = true;
				break;
			default:
				System.out.println("Incorrect input");
			}
		} while (!exit);
	}
	/**
	 * @param scanner
	 * Lets the user create a Quiz by taking the choice of topics and Difficulty from  the user,
	 * and creates a quiz,
	 * gives user an option to export Quiz in a text File.
	 */
	public static void createQuiz(Scanner scanner) {
		System.out.println("Enter the topics for the Quiz in a comma(,) separated list : ");
		String top = scanner.nextLine();
		String[] Topics = top.split(",");
		System.out.println("Enter the Difficulty level for the Quiz (1 or 2 or 3): ");
		int Level = Integer.parseInt(scanner.nextLine());
		QuestionJDBCDAO NewSearch1 = new QuestionJDBCDAO();
		List<Question> questions1 = NewSearch1.TopicSearch(Topics);
		MCQQuestionJDBCDAO NewSearch2 = new MCQQuestionJDBCDAO();
		List<MCQQuestion> questions2 = NewSearch2.TopicSearch(Topics);
		List<Question> QuizOpenQuestions = new ArrayList<>();
		List<MCQQuestion> QuizMCQQuestions = new ArrayList<>();
		for(Question ques1 : questions1) {
			if(Level == ques1.getDifficulty()) {
				QuizOpenQuestions.add(ques1);
			}
		}
		
		for(MCQQuestion ques2 : questions2) {
			if(Level == ques2.getDifficulty()) {
				QuizMCQQuestions.add(ques2);
			}
		}
		System.out.println("Enter a Title for the quiz \n (Eg: Java Quiz Easy/Medium/Hard)");
		String title = scanner.nextLine();
		Quiz NewQuiz = new Quiz();
		NewQuiz.setTitle(title);
		NewQuiz.setListQuestions(QuizOpenQuestions);
		NewQuiz.setListMCQQuestions(QuizMCQQuestions);
		QuizDAO NewDAO = new QuizDAO();
		NewDAO.create(NewQuiz);
		System.out.println("Do you Want to export quiz as text file? (y/n)");
		String in = scanner.nextLine();
		if("y".equalsIgnoreCase(in)) {
			creteTextFile(NewQuiz); 
			
		} 
		System.out.println("Quiz Created successfully ! ");
		
	}
	
	/**
	 * @param NewExam
	 * Exports a Quiz as a text file.
	 */
	public static void creteTextFile(Quiz NewExam) {
		File file = new File("D:\\"+NewExam.getTitle()+".txt");
		try {
			PrintWriter writer = new PrintWriter(new FileWriter(file, true));
		
		
		List<Question> Open = NewExam.getListQuestions();
		List<MCQQuestion> MCQ = NewExam.getListMCQQuestions();
		
		
		
		MCQChoiceJDBCDAO NewChDao = new MCQChoiceJDBCDAO();
		
		int count = 0;
		for(MCQQuestion m : MCQ) {
			count++;
			writer.println(count+") "+m.getQuestion());
			List<MCQChoice> Choices = new ArrayList<>();
			Choices =  NewChDao.search(m);
			for(int c=0;c<Choices.size();c++) {
				writer.println(c+1+") "+Choices.get(c).getLabel());
			}
			writer.println();
		}
		for(Question q : Open) {
			count++;
			writer.println(count+") "+q.getQuestion());

		}
		
		writer.flush();
		System.out.println("File Created : "+ file.getName());
		} catch (IOException e) {
			Logger.error("Exception occured while init the writer");
			e.printStackTrace();
		}
	}
	
	/**
	 * @param scanner
	 * Gets the topics from the user to facilitate fetching a list of MCQ questions based on the topics so entered.
	 */
	public static void topicSearchMCQQuestion(Scanner scanner) {
		System.out.println("Enter the topics in a comma(,) separated list : ");
		String top = scanner.nextLine();
		String[] Topics = top.split(",");
		MCQQuestionJDBCDAO NewSearch = new MCQQuestionJDBCDAO();
		List<MCQQuestion> questions = NewSearch.TopicSearch(Topics);
		for(MCQQuestion Q : questions) {
			System.out.println(Q.toString());
		}
	}
	
	/**
	 * @param scanner
	 * Gets the topics from the user to facilitate fetching a list of questions based on the topics so entered.
	 */
	public static void topicSearchOpenQuestion(Scanner scanner) {
		System.out.println("Enter the topics in a comma(,) separated list : ");
		String top = scanner.nextLine();
		String[] Topics = top.split(",");
		QuestionJDBCDAO NewSearch = new QuestionJDBCDAO();
		List<Question> questions = NewSearch.TopicSearch(Topics);
		for(Question Q : questions) {
			System.out.println(Q.toString());
		}
	}
	
	/**
	 * facilitates fetching the list of  all  MCQ questions in the System.
	 */
	public static void allMCQQuestions() {
		MCQQuestionJDBCDAO NewSearch = new MCQQuestionJDBCDAO();
		List<MCQQuestion> questions = NewSearch.search();
		for(MCQQuestion Q : questions) {
			System.out.println(Q.toString());
		}
	}
	/**
	 * facilitates fetching the list of  all Open questions in the System.
	 */
	public static void allOpenQuestions() {
		QuestionJDBCDAO NewSearch = new QuestionJDBCDAO();
		List<Question> questions = NewSearch.search();
		for(Question Q : questions) {
			System.out.println(Q.toString());
		}
	}
	
	/**
	 * @param scanner
	 * gets the id from the user to facilitate the delete MCQ question feature.
	 */
	public static void deleteMCQQuestion(Scanner scanner) {
		MCQQuestion NewQuestion = new MCQQuestion();
		System.out.println("Enter the id of the Question you wish to Delete");
		int newId = Integer.parseInt(scanner.nextLine());
		NewQuestion.setId(newId);
		MCQQuestionJDBCDAO NewDelete = new MCQQuestionJDBCDAO();
		NewDelete.delete(NewQuestion);
	}
	
	/**
	 * @param scanner
	 * gets the id from the user to facilitate the update Open question feature.
	 */
	public static void deleteOpenQuestion(Scanner scanner) {
		Question NewQuestion = new Question();
		System.out.println("Enter the id of the Question you wish to Delete");
		int newId = Integer.parseInt(scanner.nextLine());
		NewQuestion.setId(newId);
		QuestionJDBCDAO NewDelete = new QuestionJDBCDAO();
		NewDelete.delete(NewQuestion);
	}
	
	/**
	 * @param scanner
	 * gets the id from the user to facilitate the update MCQ question feature.
	 */
	public static void updateMCQQuestion(Scanner scanner) {
		MCQQuestion NewQuestion = new MCQQuestion();
		System.out.println("Enter the id of the Question you wish to Update");
		int newId = Integer.parseInt(scanner.nextLine());
		NewQuestion.setId(newId);
		System.out.println("Enter the new Question : ");
		String Ques = scanner.nextLine();
		NewQuestion.setQuestion(Ques);
		System.out.println("Enter the new Difficulty (1 or 2 or 3): ");
		int Diff = Integer.parseInt(scanner.nextLine());
		NewQuestion.setDifficulty(Diff);
		MCQQuestionJDBCDAO NewUpdate = new MCQQuestionJDBCDAO();
		NewUpdate.update(NewQuestion);
	}
	
	/**
	 * @param scanner
	 * gets the id from the user to facilitate the update Open question feature.
	 */
	public static void updateOpenQuestion(Scanner scanner) {
		Question NewQuestion = new Question();
		System.out.println("Enter the id of the Question you wish to Update");
		int newId = Integer.parseInt(scanner.nextLine());
		NewQuestion.setId(newId);
		System.out.println("Enter the new Question : ");
		String Ques = scanner.nextLine();
		NewQuestion.setQuestion(Ques);
		System.out.println("Enter the new Difficulty (1 or 2 or 3): ");
		int Diff = Integer.parseInt(scanner.nextLine());
		NewQuestion.setDifficulty(Diff);
		QuestionJDBCDAO NewUpdate = new QuestionJDBCDAO();
		NewUpdate.update(NewQuestion);
	}
	
	/**
	 * @param scanner
	 * gets the details of the MCQ question from the user to insert MCQ question in the system,
	 * also fetching and inserting the correct answer and three incorrect choices for the MCQ question.
	 */
	public static void createMCQQuestion(Scanner scanner) {
		MCQQuestion NewQuestion = new MCQQuestion();
		System.out.println("Enter  the Question : ");
		String Ques = scanner.nextLine();
		NewQuestion.setQuestion(Ques);
		System.out.println("Enter  the Difficulty (1 or 2 or 3): ");
		int Diff = Integer.parseInt(scanner.nextLine());
		NewQuestion.setDifficulty(Diff);
		System.out.println("Enter the topics in a comma(,) separated list : ");
		String top = scanner.nextLine();
		String[] Topics = top.split(",");
		NewQuestion.setTopics(Topics);
		MCQQuestionJDBCDAO NewCreate = new MCQQuestionJDBCDAO();
		int id = NewCreate.create(NewQuestion);
		NewQuestion.setId(id);
		MCQChoice NewAnswer = new MCQChoice();
		NewAnswer.setQuestion(NewQuestion);
		NewAnswer.setValid(true);
		System.out.println("Enter the Correct Choice :");
		String Ans = scanner.nextLine();
		NewAnswer.setLabel(Ans);
		System.out.println("Enter the 3 incorrect Choices :");
		String[] choices =  new String[3];
		for(int b=0;b<3;b++) {
			choices[b] = scanner.nextLine();
		}
		MCQChoice A1 = new MCQChoice();
		A1.setQuestion(NewQuestion);
		A1.setValid(false);
		A1.setLabel(choices[0]);
		MCQChoice A2 = new MCQChoice();
		A2.setQuestion(NewQuestion);
		A2.setValid(false);
		A2.setLabel(choices[1]);
		MCQChoice A3 = new MCQChoice();
		A3.setQuestion(NewQuestion);
		A3.setValid(false);
		A3.setLabel(choices[2]);
		MCQChoiceJDBCDAO NewCh = new MCQChoiceJDBCDAO();
		NewCh.create(A1);
		NewCh.create(A2);
		NewCh.create(A3);
		NewCh.create(NewAnswer);
	}
	
	/**
	 * @param scanner
	 * gets the details of the open question from the user to insert open question in the system,
	 * also fetching and inserting the correct answer for the Question.
	 */
	public static void createOpenQuestion(Scanner scanner) {
		Question NewQuestion = new Question();
		System.out.println("Enter  the Question : ");
		String Ques = scanner.nextLine();
		NewQuestion.setQuestion(Ques);
		System.out.println("Enter  the Difficulty (1 or 2 or 3): ");
		int Diff = Integer.parseInt(scanner.nextLine());
		NewQuestion.setDifficulty(Diff);
		System.out.println("Enter the topics in a comma(,) separated list : ");
		String top = scanner.nextLine();
		String[] Topics = top.split(",");
		NewQuestion.setTopics(Topics);
		Answer NewAnswer = new Answer();
		
		System.out.println("Enter the Answer :");
		String Ans = scanner.nextLine();
		NewAnswer.setText(Ans);
		QuestionJDBCDAO NewCreate = new QuestionJDBCDAO();
		int id = NewCreate.create(NewQuestion);
		NewQuestion.setId(id);
		NewAnswer.setQuestion(NewQuestion);
		AnswerJDBCDAO NewAns = new AnswerJDBCDAO();
		NewAns.create(NewAnswer);
	}
}
