package fr.epita.datamodel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import fr.epita.logger.Logger;
import fr.epita.services.dao.AnswerJDBCDAO;
import fr.epita.services.dao.MCQChoiceJDBCDAO;
import fr.epita.services.dao.QuizDAO;
import fr.epita.services.dao.StudentJDBCDAO;




/**
 * @author priyamchadha
 *Handles the interactions of the Student as a user to the system.
 */
public class StudentManager {

	
	
	/**
	 * Register's the user by getting its name,
	 * displays choice to the user of the Titles of quizzes the user can attempts,
	 * Gets the users choice and directs the control to the Choice of quiz made. 
	 */
	public static void StudentMenu() {									
		Student NewStudent = new Student();
		System.out.println("Please register : \n Enter your name: ");
		Scanner scann = new Scanner(System.in);
		String name = scann.nextLine();
		NewStudent.setName(name);
		QuizDAO NewQuiz = new QuizDAO();
		List<String> titles = NewQuiz.title();
		for(int i=0;i<titles.size();i++) {
			System.out.println(i+") "+titles.get(i));
		}
		int index = Integer.parseInt(scann.nextLine()); 
		String SearchTitle = titles.get(index);
		NewStudent.setQuiz(SearchTitle);
		NewStudent.setId("15");
		Quiz NewExam = NewQuiz.search(SearchTitle);
		String grade = launchQuiz(scann, NewExam);
		NewStudent.setGrade(grade);
		System.out.println("Your Grade is '"+grade+"'");
		StudentJDBCDAO NewStdDao = new StudentJDBCDAO();
		NewStdDao.create(NewStudent);
		System.out.println("Take another Quiz? (Y/N)");
		String input = scann.nextLine();
		if(input.equalsIgnoreCase("N")) {
			System.exit(0);
		} else if(input.equalsIgnoreCase("Y")) {
			StudentMenu();
		}
		
	}

	/**
	 * @param scann
	 * @param NewExam
	 * Displays the quiz to the user and gets the Answer that the user enters from the console,
	 * checks user's answers against the corrects answer and calculates the points(no of correct answers) for the quiz. 
	 * @return
	 */
	public static String launchQuiz(Scanner scann, Quiz NewExam) {
		int Points = 0;
		String Grade = "";
		List<String> StudentAns = new ArrayList<>();
		List<String> CorrectAns = new ArrayList<>();
		List<Question> Open = NewExam.getListQuestions();
		List<MCQQuestion> MCQ = NewExam.getListMCQQuestions();
		int Total = Open.size() + MCQ.size();
		
		
		MCQChoiceJDBCDAO NewChDao = new MCQChoiceJDBCDAO();
		AnswerJDBCDAO NewAnsDao = new AnswerJDBCDAO();
		int count = 0;
		for(MCQQuestion m : MCQ) {
			count++;
			System.out.println(count+") "+m.getQuestion());
			List<MCQChoice> Choices = new ArrayList<>();
			Choices =  NewChDao.search(m);
			for(int c=0;c<Choices.size();c++) {
				System.out.println(c+1+") "+Choices.get(c).getLabel());
			}
			System.out.println("Enter the Answer (1, 2, 3 or 4):");
			int Std = Integer.parseInt(scann.nextLine());
			StudentAns.add(Choices.get(Std-1).getLabel());
			if(Choices.get(Std-1).isValid()) {
				Points++;
			}
			for(MCQChoice ch : Choices) {
				if(ch.isValid()) {
					CorrectAns.add(ch.getLabel());
					break;
				}
			}
		}
		for(Question q : Open) {
			count++;
			System.out.println(count+") "+q.getQuestion());
			List<Answer> ans = new ArrayList<>();
			ans = NewAnsDao.search(q);
			System.out.println("Enter the Answer :");
			
			String St = scann.nextLine();
			StudentAns.add(St);
			CorrectAns.add(ans.get(0).getText());
			if(ans.get(0).getText().equalsIgnoreCase(St)) {
				Points++;
			}

		}

		Grade = calcGrade(Points, Total);
		return Grade;
	}

	/**
	 * @param Points
	 * @param Total
	 * Calculates the Grade from the Student's points and total points,
	 * returns the Grade.
	 * @return
	 */
	public static String calcGrade(int Points, int Total) {
		String Grade;
		double score;
		score=((double)Points/Total)*100;
		
		if(score<=40){
			Grade = "C";
		} else if(score<=70) {
			Grade = "B";
		} else {
			Grade = "A";
		}
		return Grade;
	}
	
	
	
}
