package fr.epita.datamodel;

import java.util.List;

public class Quiz {
	private String title;
	
	private List<Question> listQuestions;
	
	private List<MCQQuestion> listMCQQuestions;

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the listQuestions
	 */
	public List<Question> getListQuestions() {
		return listQuestions;
	}

	/**
	 * @param listQuestions the listQuestions to set
	 */
	public void setListQuestions(List<Question> listQuestions) {
		this.listQuestions = listQuestions;
	}

	/**
	 * @return the listMCQQuestions
	 */
	public List<MCQQuestion> getListMCQQuestions() {
		return listMCQQuestions;
	}

	/**
	 * @param listMCQQuestions the listMCQQuestions to set
	 */
	public void setListMCQQuestions(List<MCQQuestion> listMCQQuestions) {
		this.listMCQQuestions = listMCQQuestions;
	}


	
	
}
