package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.Answer;
import fr.epita.datamodel.Question;
import fr.epita.services.Configuration;

/**
 * @author priyamchadha
 *This class handles the Database DAO for the Answer class.
 *which is fetching, writing and editing the data to/from database for Answer class objects.
 */
public class AnswerJDBCDAO {
 
	private static final String INSERT_QUERY = "INSERT INTO ANSWER (LABEL,QUESTIONID) VALUES (?, ?)";
	private static final String DELETE_QUERY = "DELETE ANSWER WHERE QUESTIONID=?";
	private static final String SEARCH_QUERY = "SELECT QUESTIONID,LABEL FROM ANSWER WHERE QUESTIONID=?";
	
	
	
	/**
	 * @param answer
	 * Inserts the answer object passed into Database.
	 */
	public void create(Answer answer) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(INSERT_QUERY);
			stmt.setString(1, answer.getText());
			stmt.setInt(2, answer.getQuestion().getId());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * @param question
	 * Deletes an Answer row from the database associated with the question passed to the function.
	 */
	public void delete(Question question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(DELETE_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param question
	 * Searches the Answer in database associated with the question passed to the function,
	 * gets the data from result set,
	 * then, returns the answer as an Array list of Answer objects.
	 * @return 
	 */
	public List<Answer> search(Question question) {
		List<Answer> ans = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			stmt.setInt(1, question.getId());
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String Label = rs.getString(2);
				Answer current = new Answer();
				current.setQuestion(question);
				current.setText(Label);
				ans.add(current);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ans;
	}

	/**
	 * Sets up a new connection to the database and returns the connection.
	 * @return
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}

}
