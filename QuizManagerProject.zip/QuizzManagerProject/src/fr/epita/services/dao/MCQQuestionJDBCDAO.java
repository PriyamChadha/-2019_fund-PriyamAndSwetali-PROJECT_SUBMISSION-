package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.MCQQuestion;
import fr.epita.datamodel.Question;
import fr.epita.services.Configuration;

/**
 * @author priyamchadha
 *This class handles the Database DAO for the MCQQuestion class.
 *which is fetching, writing and editing the data to/from database for MCQQuestion class Objects.
 */
public class MCQQuestionJDBCDAO {

	private static final String INSERT_QUERY = "INSERT INTO MCQQUESTION (LABEL,DIFFICULTY,TOPICS) VALUES (?, ?, ?)";
	private static final String UPDATE_QUERY = "UPDATE MCQQUESTION SET LABEL=?,DIFFICULTY=? WHERE ID=?";
	private static final String DELETE_QUERY = "DELETE MCQQUESTION WHERE ID=?";
	private static final String SEARCH_QUERY = "SELECT LABEL,ID,DIFFICULTY,TOPICS FROM MCQQUESTION";
	
	
	
	/**
	 * @param question
	 * Inserts MCQ Question passed to the function into the database table.
	 * @return 
	 */
	public int create(MCQQuestion question) {
		String[] topics = question.getTopics();
		String DBTopics = String.join(",", topics);
		int id = 0;
		
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(INSERT_QUERY,Statement.RETURN_GENERATED_KEYS);
			
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.setString(3, DBTopics);
			stmt.executeUpdate();
			ResultSet keys = stmt.getGeneratedKeys();
			keys.next();
			id = keys.getInt(1);
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	/**
	 * @param question
	 * Update the question in database for the Question id passed to the function. 
	 */
	public void update(MCQQuestion question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(UPDATE_QUERY);
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.setInt(3, question.getId());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * @param question
	 * Delete a Question from the database associate with the Question object passed to the function.
	 */
	public void delete(MCQQuestion question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(DELETE_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Reads all the MCQ question from the database,
	 * stores them in the form of MCQQuestion Objects,
	 * then returns the list of MCQQuestion objects.
	 * @return
	 */
	public List<MCQQuestion> search() {
		List<MCQQuestion> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String questionLabel = rs.getString(1);
				int id = rs.getInt(2);
				int difficulty = rs.getInt(3);
				String topics = rs.getString(4);
				String[] parts = topics.split(",");
				MCQQuestion currentQuestion = new MCQQuestion();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				currentQuestion.setTopics(parts);
				questions.add(currentQuestion);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;
	}
	
	/**
	 * @param Topics
	 * Searches all the MCQ question from the database for the TOPICS passed to the function,
	 * stores them in the form of MCQQuestion Objects, 
	 * then returns the list of MCQQuestion objects.
	 * @return
	 */
	public List<MCQQuestion> TopicSearch(String[] Topics) {
		List<MCQQuestion> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String questionLabel = rs.getString(1);
				int id = rs.getInt(2);
				int difficulty = rs.getInt(3);
				String topics = rs.getString(4);
				String[] parts = topics.split(",");
				MCQQuestion currentQuestion = new MCQQuestion();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				currentQuestion.setTopics(parts);
				for(int a=0;a<parts.length;a++) {
					for(int b=0;b<Topics.length;b++) {
						if(parts[a].equalsIgnoreCase(Topics[b])) {
							questions.add(currentQuestion);
						}
					}
				}
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return questions;
	}

	/**
	 * Sets up a new connection to the database and returns the connection.
	 * @return
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}

}
