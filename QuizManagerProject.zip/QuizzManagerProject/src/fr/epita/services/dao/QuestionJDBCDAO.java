package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.Question;
import fr.epita.services.Configuration;

/**
 * @author priyamchadha
 *This class handles the Database DAO for the Question class.
 *which is fetching, writing and editing the data to/from database for Question class Objects.
 */
public class QuestionJDBCDAO {

	private static final String INSERT_QUERY = "INSERT INTO QUESTIONS (QUESTION,DIFFICULTY,TOPICS) VALUES (?, ?, ?)";
	private static final String UPDATE_QUERY = "UPDATE QUESTIONS SET QUESTION=?,DIFFICULTY=? WHERE ID=?";
	private static final String DELETE_QUERY = "DELETE QUESTIONS WHERE ID=?";
	private static final String SEARCH_QUERY = "SELECT QUESTION,ID,DIFFICULTY,TOPICS FROM QUESTIONS";
	
	
	
	/**
	 * @param question
	 * Inserts Question in the database passed to the function.
	 * @return
	 */
	public int create(Question question) {
		String[] topics = question.getTopics();
		String DBTopics = String.join(",", topics);
		int id = 0;
		
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(INSERT_QUERY,Statement.RETURN_GENERATED_KEYS);
			
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.setString(3, DBTopics);
			stmt.executeUpdate();
			ResultSet keys = stmt.getGeneratedKeys();
			keys.next();
			id = keys.getInt(1);
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	
	/**
	 * @param question
	 * Updates a question in the database for the question id passed to the function.
	 */
	public void update(Question question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(UPDATE_QUERY);
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.setInt(3, question.getId());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param question
	 * Deletes the question from the database for the Question id passed to the function.
	 */
	public void delete(Question question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(DELETE_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Reads all the questions from the database,
	 * stores them in the Question objects
	 * returns an array list of Question Objects.
	 * @return
	 */
	public List<Question> search() {
		List<Question> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String questionLabel = rs.getString(1);
				int id = rs.getInt(2);
				int difficulty = rs.getInt(3);
				String topics = rs.getString(4);
				String[] parts = topics.split(",");
				Question currentQuestion = new Question();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				currentQuestion.setTopics(parts);
				questions.add(currentQuestion);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;
	}
	
	/**
	 * @param Topics
	 * Reads all the Question from the database associated to the list of objects passed to the function,
	 * stores them in the Question objects,
	 * returns an array list of Question objects.
	 * @return
	 */
	public List<Question> TopicSearch(String[] Topics) {
		List<Question> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String questionLabel = rs.getString(1);
				int id = rs.getInt(2);
				int difficulty = rs.getInt(3);
				String topics = rs.getString(4);
				String[] parts = topics.split(",");
				Question currentQuestion = new Question();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				currentQuestion.setTopics(parts);
				for(int a=0;a<parts.length;a++) {
					for(int b=0;b<Topics.length;b++) {
						if(parts[a].equalsIgnoreCase(Topics[b])) {
							questions.add(currentQuestion);
							break;
						}
					}
				}
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return questions;
	}

	/**
	 * Sets up a new connection to the database and returns the connection.
	 * @return
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}

}
