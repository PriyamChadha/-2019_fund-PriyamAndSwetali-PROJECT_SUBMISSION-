package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.Answer;
import fr.epita.datamodel.Question;
import fr.epita.datamodel.Quiz;
import fr.epita.datamodel.Student;
import fr.epita.services.Configuration;

/**
 * @author priyamchadha
 *This class handles the Database DAO for the Student class.
 *which is fetching, writing and editing the data to/from database for Student class.
 */
public class StudentJDBCDAO {

	private static final String INSERT_QUERY = "INSERT INTO STUDENT (NAME,GRADE,QUIZ) VALUES (?, ?, ?)";
	private static final String DELETE_QUERY = "DELETE STUDENT WHERE ID=?";
	private static final String SEARCH_QUERY = "SELECT ID,NAME,GRADE,QUIZ FROM STUDENT WHERE QUIZ=?";
	
	
	
	/**
	 * @param student
	 * Inserts the student into database, assciated with Student object passed.
	 */
	public void create(Student student) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(INSERT_QUERY);
			
			stmt.setString(1, student.getName());
			stmt.setString(2, student.getGrade());
			stmt.setString(3, student.getQuiz());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * @param student
	 * Deletes the row from database associated with the Student object passed to the function.
	 */
	public void delete(Student student) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(DELETE_QUERY);
			stmt.setString(1, student.getId());
			
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param quiz
	 * Reads all the Students from the database associated with Quiz object passed to the function,
	 * stores the result set in the student objects,
	 * returns the array list of Student objects.
	 * @return
	 */
	public List<Student> search(Quiz quiz) {
		List<Student> std = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			stmt.setString(1, quiz.getTitle());
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String id = rs.getString(1);
				String name = rs.getString(2);
				String gra = rs.getString(3);
				
				Student current = new Student();
				current.setId(id);
				current.setName(name);
				current.setGrade(gra);
				current.setGrade(quiz.getTitle());
				std.add(current);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return std;
	}

	/**
	 * Sets up a new connection to the database and returns the connection.
	 * @return
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}

}
