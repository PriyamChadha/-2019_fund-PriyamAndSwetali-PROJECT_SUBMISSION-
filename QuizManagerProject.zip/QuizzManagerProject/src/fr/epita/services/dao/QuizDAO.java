package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.Answer;
import fr.epita.datamodel.MCQQuestion;
import fr.epita.datamodel.Question;
import fr.epita.datamodel.Quiz;
import fr.epita.services.Configuration;

/**
 * @author priyamchadha
 *This class handles the Database DAO for the Quiz class.
 *which is fetching, writing and editing the data to/from database for Quiz class Objects.
 */
public class QuizDAO {

	private static final String INSERT_QUERY = "INSERT INTO QUIZ (TITLE,OPENQUESTIONS,MCQQUESTIONS) VALUES (?, ?, ?)";
	private static final String SEARCH_QUERY = "SELECT TITLE,OPENQUESTIONS,MCQQUESTIONS FROM QUIZ WHERE TITLE=?";
	private static final String SEARCH_TITLE = "SELECT TITLE FROM QUIZ";
	
	
	/**
	 * @param quiz
	 * Inserts a new Quiz in the database associated with the quiz object passed to the function.
	 */
	public void create(Quiz quiz) {
		
		List<String> OpenQuestions = new ArrayList<>();
		List<String> MCQQuestions = new ArrayList<>();
		for(Question Q : quiz.getListQuestions()) {
			OpenQuestions.add(Integer.toString(Q.getId()));
		}
		for(MCQQuestion M : quiz.getListMCQQuestions()) {
			MCQQuestions.add(Integer.toString(M.getId()));
		}
		String OpenID = String.join(",", OpenQuestions);
		String MCQID = String.join(",", MCQQuestions);
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(INSERT_QUERY);
			stmt.setString(1, quiz.getTitle());
			stmt.setString(2, OpenID);
			stmt.setString(3, MCQID);
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param Title
	 * Reads/searches a quiz in the database associated with the Title passed to the function,
	 * Stores the result set in the Quiz Object,
	 * Returns the quiz object.
	 * @return
	 */
	public Quiz search(String Title) {
		QuestionJDBCDAO ques1 = new QuestionJDBCDAO();
		List<Question> AllOpen = ques1.search();
		MCQQuestionJDBCDAO ques2 = new MCQQuestionJDBCDAO();
		List<MCQQuestion> AllMCQ = ques2.search();
		Quiz quiz = new Quiz();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			stmt.setString(1, Title);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			String title = rs.getString(1);
			String Open = rs.getString(2);
			String MCQ = rs.getString(3);
			String[] open = Open.split(",");
			String[] mcq = MCQ.split(",");
			stmt.close();
			connection.close();
			List<Question> QuizOpen = new ArrayList<>();
			List<MCQQuestion> QuizMCQ = new ArrayList<>();
			for(Question q : AllOpen) {
				for(int i=0;i<open.length;i++) {
					if(Integer.parseInt(open[i]) == q.getId()) {
						QuizOpen.add(q);
					}
				}
			}
			for(MCQQuestion m : AllMCQ) {
				for(int i=0;i<mcq.length;i++) {
					if(Integer.parseInt(mcq[i]) == m.getId()) {
						QuizMCQ.add(m);
					}
				}
			}
			
			quiz.setTitle(title);
			quiz.setListQuestions(QuizOpen);
			quiz.setListMCQQuestions(QuizMCQ);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quiz;
	}
	
	/**
	 * Fetches the titles of all the Quiz in the database,
	 * Returns an array list of Strings, titles so read from the database. 
	 * @return
	 */
	public List<String> title() {
		List<String> titles = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_TITLE);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String Label = rs.getString(1);
				titles.add(Label);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return titles;
	}

	/**
	 * Sets up a new connection to the database and returns the connection.
	 * @return
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}
}
